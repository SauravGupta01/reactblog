import React, { Component } from 'react';

class Page404 extends Component {
  render() {
    return (
      <div>
        <h1>404: Nothing found here!</h1>
      </div>
    );
  }
}

export default Page404;
